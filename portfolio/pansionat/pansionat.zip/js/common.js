jQuery(function ($) {


		$(".fancybox").fancybox();
 
 $('.spis_zabol_right li, .spis_zabol li').hover(
       function(){ $(this).addClass('tablet') },
       function(){ $(this).removeClass('tablet') }
);

 
// текущая дата
var date = new Date();

// час в текущей временной зоне
var hr = date.getHours();

if (hr==8 && hr<9) {$('.block_time .v8').addClass('active') };
if (hr==9 && hr<10) {$('.block_time .v9').addClass('active') };
if (hr>=10 && hr<12) {$('.block_time .v10').addClass('active') }
if (hr>=12 && hr<14) {$('.block_time .v12').addClass('active') }
if (hr>=14 && hr<16) {$('.block_time .v14').addClass('active') }
if (hr>=16 && hr<18) {$('.block_time .v16').addClass('active') }
if (hr>=18 && hr<20) {$('.block_time .v18').addClass('active') }
if (hr==19 && hr<20) {$('.block_time .v19').addClass('active') }
if (hr>=20 && hr<22) {$('.block_time .v20').addClass('active') }
if (hr==22 && hr<23) {$('.block_time .v22').addClass('active') }

 

 
//ползунок
var age =  $('.polzyn input').val();
 
 	//Аякс отправка форм
	//Документация: http://api.jquery.com/jquery.ajax/
	$("form").submit(function() {
		$.ajax({
			type: "GET",
			url: "mail.php",
			data: $("form").serialize()
		}).done(function() {
			alert("Спасибо за заявку!");
			setTimeout(function() {
				$.fancybox.close();
			}, 1000);
		});
		return false;
	});





});

